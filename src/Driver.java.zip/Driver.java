import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Driver {
    public static void main(String args[]) {

        //initialize variable for the file reader
        File inputFile;
        String inputFileName;

        try {

            //file scanner
            Scanner s = new Scanner(System.in);
            System.out.println("Please enter a File name from the working directory: ");
            inputFileName = s.next();
            inputFile = new File(inputFileName);
            Scanner fileScanner = new Scanner(inputFile);

            int heapSize = 0;

            //loops through the file and counts the size
            while (fileScanner.hasNext()) {
                heapSize++;
                fileScanner.next();
            }

            int dashAmount = heapSize - 1;

            s.close();
            fileScanner.close();


            fileScanner = new Scanner(inputFile);
            MinHeap heap = new MinHeap(heapSize);
            System.out.println("Building Min Heap");

            //loops through the file and creates the min heap and adds the dashes to the empty spaces
            while (fileScanner.hasNext()) {
                heap.add(Integer.parseInt(fileScanner.next()));
                heap.printHeap();
                for (int i = dashAmount; i >= 0; i--) {
                    System.out.print("--- ");
                }
                dashAmount--;
                System.out.println();
            }

            System.out.println();

            //sorting the min heap
            int[] heap2 = heap.getHeap();
            HeapSort sortedHeap = new HeapSort();
            System.out.println("Sorting the Min Heap from greatest to least");
            sortedHeap.sort(heap2);


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
